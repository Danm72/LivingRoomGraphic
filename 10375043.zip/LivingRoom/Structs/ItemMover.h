#import "GLUT/glut.h"

typedef struct {
    GLfloat tableX;
    GLfloat tableY;
    GLfloat tableZ;

    GLfloat chairX;
    GLfloat chairY;
    GLfloat chairZ;

    int itemToMove;

} item_mover;