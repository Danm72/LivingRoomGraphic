#import "GLUT/glut.h"

void glutSolidCube_tex(GLdouble size,float repeats);
