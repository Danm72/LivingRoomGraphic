#import "GLUT/glut.h"

typedef struct {
    GLuint wood;
    GLuint bookcase;
    GLuint cream;
    GLuint oak;
    GLuint wood4;
    GLuint bookshelf;
    GLuint wood_desk;
    GLuint fabric;
    GLuint frame;
    GLuint leather;

} textures;