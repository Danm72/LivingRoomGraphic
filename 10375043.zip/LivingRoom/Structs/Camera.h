#import "GLUT/glut.h"

typedef struct {
    GLdouble eyeX;
    GLdouble eyeY;
    GLdouble eyeZ;
    GLdouble centerX;
    GLdouble centerY;
    GLdouble centerZ;
    GLdouble upX;
    GLdouble upY;
    GLdouble upZ;
    int debugMode;
} camera;