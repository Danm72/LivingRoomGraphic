#include <GLUT/GLUT.h>

GLuint startList;

void placeItem(GLfloat trans [], GLfloat rotate [], GLfloat scale []);
