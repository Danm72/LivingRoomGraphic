#import "GLUT/glut.h"
#import "Drawer.h"

void drawBookCase();

void drawBookFace();

void setupBookCase();

treenode bookcase_node;
treenode bookface_node;