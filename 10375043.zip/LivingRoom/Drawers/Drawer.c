#import "Drawer.h"

//textures *tex;

void initTextures(textures *tex1) {
    tex = tex1;
}