#import "GLUT/glut.h"
#import "Drawer.h"
#import "TreeNode.h"

treenode frame1_node;
treenode frame2_node;

void drawWindowFace1();

void drawWindowFace2();

void setupWindows();
