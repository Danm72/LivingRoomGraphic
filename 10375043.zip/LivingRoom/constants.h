#ifndef CONSTANTS_H

#define CHAIR_NUM 1;
#define TABLE_NUM 2;
#define WALL_NUM 3;
#define BOOKCASE_NUM 4;

#endif